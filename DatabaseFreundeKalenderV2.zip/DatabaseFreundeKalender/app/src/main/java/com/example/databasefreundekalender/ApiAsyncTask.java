
package com.example.databasefreundekalender;

import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.extensions.android.gms.auth.GooglePlayServicesAvailabilityIOException;
import com.google.api.client.googleapis.extensions.android.gms.auth.UserRecoverableAuthIOException;
import com.google.api.client.util.DateTime;

import com.google.api.services.calendar.model.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;




/**
 * An asynchronous task that handles the Google Calendar API call.
 * Placing the API calls in their own task ensures the UI stays responsive.
 */





/**
 * Created by miguel on 5/29/15.
 */



@SuppressWarnings("ALL")
public class ApiAsyncTask extends AsyncTask<Void, Void, Void> {
    private MainActivity mActivity;
    final String calenderIDPhilippDaniel = "ba05d6a754c2cedefaf60921f979180e2d1bbd57026caee2b59b63d6cf9230c4@group.calendar.google.com";


/**
     * Constructor.
     * @param activity MainActivity that spawned this task.
     */


    ApiAsyncTask(MainActivity activity) {
        this.mActivity = activity;
    }



/**
     * Background task to call Google Calendar API.
     * @param params no parameters needed for this task.
     */


    @Override
    protected Void doInBackground(Void... params) {
        try {
            mActivity.clearResultsText();
            mActivity.updateResultsText(getDataFromApi());
           // addNewEventToAPI();
            editEvent();
        } catch (final GooglePlayServicesAvailabilityIOException availabilityException) {
            mActivity.showGooglePlayServicesAvailabilityErrorDialog(
                    availabilityException.getConnectionStatusCode());

        } catch (UserRecoverableAuthIOException userRecoverableException) {
            mActivity.startActivityForResult(
                    userRecoverableException.getIntent(),
                    MainActivity.REQUEST_AUTHORIZATION);

        } catch (IOException e) {
            mActivity.updateStatus("The following error occurred: " +
                    e.getMessage());
        }
        return null;
    }



/**
     * Fetch a list of the next 10 events from the primary calendar.
     * @return List of Strings describing returned events.
     * @throws IOException
     */


    private List<String> getDataFromApi() throws IOException {
        // List the next 10 events from the primary calendar.
        DateTime now = new DateTime(System.currentTimeMillis());
        List<String> eventStrings = new ArrayList<String>();
        Events events = mActivity.mService.events().list("ba05d6a754c2cedefaf60921f979180e2d1bbd57026caee2b59b63d6cf9230c4@group.calendar.google.com")
                .setMaxResults(10)
                .setTimeMin(now)
                .setOrderBy("startTime")
                .setSingleEvents(true)
                .execute();
        List<Event> items = events.getItems();

        for (Event event : items) {
            DateTime start = event.getStart().getDateTime();
            if (start == null) {
                // All-day events don't have start times, so just use
                // the start date.
                start = event.getStart().getDate();
            }
            eventStrings.add(
                    String.format("%s (%s)", event.getSummary(), start));
        }
        return eventStrings;
    }

    // Testmethode um API zu testen
    private void addNewEventToAPI() throws IOException {
        Event event = new Event();
        event.setStart(new EventDateTime().setDateTime(new DateTime("2023-02-14T13:15:03-08:00")));
        event.setEnd(new EventDateTime().setDateTime(new DateTime("2023-02-14T13:15:03-08:00")));
        event.setSummary("Das ist ein Test-Termin erstellt über API");
        mActivity.mService.events().insert(calenderIDPhilippDaniel, event).execute();
        Log.d("API Calender" ,"Anfrage sollte durch sein");
    }

    private void editEvent() throws IOException {
        DateTime now = new DateTime(System.currentTimeMillis());
        Events events = mActivity.mService.events().list(calenderIDPhilippDaniel)
                .setMaxResults(10)
                .setTimeMin(now)
                .setOrderBy("startTime")
                .setSingleEvents(true)
                .execute();
        List<Event> items = events.getItems();
        Event eventToEdit = items.get(0);
        Log.d("API Calender", "EventID von EditEvent: " + eventToEdit.getId());
        Log.d("API Calender", "EditEvent" + eventToEdit.toString());
        eventToEdit.setSummary("Das ist jetzt eine andere Summary");
        eventToEdit.setDescription("ahhhhh");
        Log.d("API Calender", "EditEvent" + eventToEdit.toString());
        eventToEdit.setUpdated(now);
        mActivity.mService.events().update(calenderIDPhilippDaniel,eventToEdit.getId(),eventToEdit).execute();
    }
}

